
/************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                    */
/*                                                                                  */
/*  FILE NAME             :  testmenu.c                                             */
/*  PRINCIPAL AUTHOR      :  Mengning                                               */
/*  SUBSYSTEM NAME        :  menu                                                   */
/*  MODULE NAME           :  testmenu                                               */
/*  LANGUAGE              :  C                                                      */
/*  TARGET ENVIRONMENT    :  ANY                                                    */
/*  DATE OF FIRST RELEASE :  2014/09/19                                             */
/*  DESCRIPTION           :  This is a testmenu program                             */
/************************************************************************************/

/*
 *Revision log:
 *
 *Created by Liang Dong, 2014/9/19
 */

#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"
#include "menu.h"

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     6

main()
{	
	tLinkTable * pLinkTable = InitCmd();
	tDataNode *p = NULL;
	
	while(1)
	{
		char cmd[CMD_MAX_LEN];
		
		printf("Plase input a cmd number > ");
		scanf("%s",cmd);
		p = FindCmd(pLinkTable, cmd);
		if(p == NULL)
		{
			printf("This is a wrong cmd!\n");
			continue;
		}
		printf("%s - %s\n",p->cmd,p->desc);
		RunCmdHander(pLinkTable, p);
	}
}

