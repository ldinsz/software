
/************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                    */
/*                                                                                  */
/*  FILE NAME             :  menu.h                                                 */
/*  PRINCIPAL AUTHOR      :  Mengning                                               */
/*  SUBSYSTEM NAME        :  menu                                                   */
/*  MODULE NAME           :  menu                                                   */
/*  LANGUAGE              :  C                                                      */
/*  TARGET ENVIRONMENT    :  ANY                                                    */
/*  DATE OF FIRST RELEASE :  2014/09/19                                             */
/*  DESCRIPTION           :  This is a menu head program                            */
/************************************************************************************/

/*
 *Revision log:
 *
 *Created by Liang Dong, 2014/9/19
 */
#ifndef _MENU_H_
#define _MENU_H_

#include "linktable.h"

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM	    6

//typedef struct DataNode tDataNode;
typedef struct DataNode 
{
	tLinkTableNode * pNext;
	char cmd[CMD_MAX_LEN];
	char desc[DESC_LEN];
	int (*hander)(tLinkTable * pLinkTable);
}tDataNode;
/*
 * print all cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable);
/*
 * find a cmd
 */
tDataNode* FindCmd(tLinkTable *pLinkTable, char *cmd);
/*
 * init cmd list
 */
tLinkTable * InitCmd();
/*
 * run cmd hander
 */
int RunCmdHander(tLinkTable * pLinkTable, tDataNode * pNode);

#endif


