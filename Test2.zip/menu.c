
/************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                    */
/*                                                                                  */
/*  FILE NAME             :  menu.c                                                 */
/*  PRINCIPAL AUTHOR      :  Mengning                                               */
/*  SUBSYSTEM NAME        :  menu                                                   */
/*  MODULE NAME           :  menu                                                   */
/*  LANGUAGE              :  C                                                      */
/*  TARGET ENVIRONMENT    :  ANY                                                    */
/*  DATE OF FIRST RELEASE :  2014/09/19                                             */
/*  DESCRIPTION           :  This is a menu program                                 */
/************************************************************************************/

/*
 *Revision log:
 *
 *Created by Liang Dong, 2014/9/19
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linktable.h"
#include "menu.h"

static tDataNode data[CMD_NUM];
/*
 * print all cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable)
{
	if(pLinkTable == NULL)
	{
		return FAILURE;
	}
	printf("*****************************************\n");
	printf("Menu List:				 \n");
	tDataNode *pNode = (tDataNode *)GetLinkTableHead(pLinkTable);		
	while(pNode != NULL)
	{
		printf("	%s, %s\n", pNode->cmd, pNode->desc);
		pNode = (tDataNode *)GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)pNode);
	}
	printf("*****************************************\n");
	return SUCCESS;
}
/*
 * find a cmd
 */
tDataNode* FindCmd(tLinkTable * pLinkTable, char *cmd)
{
	if((pLinkTable == NULL)||(cmd == NULL))
	{
		return NULL;
	}
	tDataNode *pNode = (tDataNode *)GetLinkTableHead(pLinkTable);

	while(pNode != NULL)
	{
		if(!strcmp(pNode->cmd, cmd))
		{
			return pNode;
			
		}
		pNode = (tDataNode *)GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)pNode);
	}
	
	return NULL;
}
/*
 * init cmd list
 */
tLinkTable * InitCmd()
{
	tLinkTable * pLinkTable = CreateLinkTable();	
	int i;
	for(i = 0; i < CMD_NUM; i++) 
	{       
        	AddLinkTableNode(pLinkTable,(tLinkTableNode *)&data[i]);
	}
	return pLinkTable;
}
/*
 * run help cmd
 */
int Help(tLinkTable *pLinkTable)
{
	if(pLinkTable == NULL)
	{
		return FAILURE;
	}
	ShowAllCmd(pLinkTable);
	return SUCCESS;
}
/*
 * run init cmd
 */
int Init(tLinkTable * pLinkTable)
{
	if(pLinkTable == NULL)
	{
		return FAILURE;
	}
	pLinkTable = InitCmd();
	return SUCCESS;
}
/*
 * run add cmd
 */
int Add(tLinkTable *pLinkTable)
{
	char AddCmd[CMD_MAX_LEN];
	char AddDesc[DESC_LEN];
	if(pLinkTable == NULL)
	{
		return FAILURE;
	}
	tDataNode * pAdd = (tDataNode *)malloc(sizeof(tDataNode));
	tDataNode * pTempNode;
	
	printf("Plase input AddCmd name > ");
	scanf("%s", AddCmd);
	pTempNode = FindCmd(pLinkTable, AddCmd);
	if(pTempNode != NULL)
	{
		printf("Cmd is existed!\n");
		return FAILURE;
	}
	strcpy(pAdd->cmd, AddCmd);
	printf("Plase input cmd desc > ");
	scanf("%s", AddDesc);
	strcpy(pAdd->desc, AddDesc);
	pAdd->pNext = NULL;
	pAdd->hander = NULL;
	AddLinkTableNode(pLinkTable,(tLinkTableNode *)pAdd);
	
	return SUCCESS;
}
/*
 * run del cmd
 */
int Del(tLinkTable * pLinkTable)
{
	char DelCmd[CMD_MAX_LEN];
	tDataNode * pTempNode;
	if(pLinkTable == NULL)
	{
		return FAILURE;
	}	
	printf("Plase input DelCmd name > ");
	scanf("%s", DelCmd);
	pTempNode = FindCmd(pLinkTable, DelCmd);
	if(pTempNode == NULL)
	{
		printf("Cmd is not existed!\n");
		return FAILURE;
	}
	DelLinkTableNode(pLinkTable, (tLinkTableNode * )pTempNode);

	return SUCCESS;
}
/*
 * run exit cmd
 */
int Exit(tLinkTable * pLinkTable)
{
	if(pLinkTable == NULL)
	{
		return FAILURE;
	}
	DeleteLinkTable(pLinkTable);
	exit(0);
	return SUCCESS;
}
/*
 * init data list
 */
static tDataNode data[CMD_NUM] = 
{
	{NULL, "help", "This is help cmd!", Help},
	{NULL, "init", "This is init cmd!", Init},
	{NULL, "version", "menu program 1.0", NULL},
	{NULL, "add", "This is add cmd!", Add},
	{NULL, "del", "This is del cmd!", Del},
	{NULL, "exit", "This is exit cmd!", Exit}
};
/*
 * run cmd hander
 */
int RunCmdHander(tLinkTable * pLinkTable, tDataNode * pNode)
{
	if((pLinkTable == NULL)||(pNode == NULL))
	{
		return FAILURE;
	}
	if(pNode->hander == NULL)
	{
		return FAILURE;
	}
	pNode->hander(pLinkTable);
	return SUCCESS;
}
