
/************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                    */
/*                                                                                  */
/*  FILE NAME             :  menu.h                                                 */
/*  PRINCIPAL AUTHOR      :  Mengning                                               */
/*  SUBSYSTEM NAME        :  menu                                                   */
/*  MODULE NAME           :  menu                                                   */
/*  LANGUAGE              :  C                                                      */
/*  TARGET ENVIRONMENT    :  ANY                                                    */
/*  DATE OF FIRST RELEASE :  2014/09/19                                             */
/*  DESCRIPTION           :  This is a menu head program                            */
/************************************************************************************/

/*
 *Revision log:
 *
 *Created by Liang Dong, 2014/9/19
 */
#ifndef _MENU_H_
#define _MENU_H_

#include "linktable.h"

#define CMD_MAX_LEN 128
#define DESC_LEN    128
#define debug

typedef struct CmdNode 
{
	tLinkTableNode * pNext;
	char cmd[CMD_MAX_LEN];
	char desc[DESC_LEN];
	int (*hander)(tLinkTable * pLinkMenu);
}tCmdNode;
/*
 * create menu
 */
tLinkTable * CreateMenu();
/*
 * start menu
 */
int MenuStart(tLinkTable * pLinkMenu);
/*
 * delete menu
 */
int DeleteMenu(tLinkTable * pLinkMenu);
/*
 * add cmd
 */
int AddCmd(tLinkTable * pLinkMenu, char * cmd, char * desc);
/*
 * delete cmd
 */
int DelCmd(tLinkTable * pLinkMenu, char * cmd);
/*
 * print menu list
 */
int ShowAllCmd(tLinkTable * pLinkMenu);
/*
 * find cmd
 */
tCmdNode * FindCmd(tLinkTable * pLinkMenu, char *cmd);
/*
 * run cmd
 */
int RunCmdHander(tLinkTable * pLinkMenu, tCmdNode * pNode);
#endif


